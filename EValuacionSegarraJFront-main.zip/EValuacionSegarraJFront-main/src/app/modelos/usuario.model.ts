export interface Usuario {
    idUsuario?: number;
    cedula: string; 
    nombre: string;
    partidoPolitico: string; 
}
  